<?php
if (!defined('RAPIDLEECH')) {
	require_once("index.html");
	exit;
}
if($options['latest_news']) {
require_once(CLASS_DIR."maxNews.class.php"); 
$newsHandler = new maxNews();  
}
?>
<div name="color_schem">
<?php if($options['color_schem_box']){?>
    <input title="White" type="submit" class="amin_color" name="white" value=" " >
    <input title="Blue" type="submit" class="amin_color" name="blue" value=" ">
    <input title="Green" type="submit" class="amin_color" name="green" value=" ">
    <input title="Yellow" type="submit" class="amin_color" name="yellow" value=" ">
    <input title="Orange" type="submit" class="amin_color" name="orange" value=" ">
    <input title="Red" type="submit" class="amin_color" name="red" value=" "><br>
<!--    <input title="Opacity" type="range" class="amin_color" name="opacity" value="100"> -->
  </div><?php }?>

<?php if($options['setting'] || $options['server_files'] || $options['admin_mail']){ ?>
  <div color="<?php echo $amin_color; ?>" class="defult">
    <div class="_div2">
      <div class="_div3">
          <div class="onvan">Menu</div>
        <div class="neveshte">
        <div class="neveshte_inner" align="center" id="menu" role="navigation">
        <nav>
        <input id="navcell1" type="button" value="<?php echo lang(329); ?>" class="selected" onClick="javascript:switchCell_amin(1); $('#link').focus();" />
        <?php if($options['setting']){ ?>
        <input id="navcell2" type="button" value="<?php echo lang(330); ?>" onClick="javascript:switchCell_amin(2);"/><?php }?>
        <?php if($options['server_files']){ ?>
        <input id="navcell3" type="button" value="<?php echo lang(331); ?>" onClick="switchCell_amin(3);" /><?php }?>
        <?php if($options['admin_mail']){ ?>
        <input id="navcell4" type="button" value="Contact us" onClick="javascript:switchCell_amin(4); $('#captcha_image').attr('background','captcha.php');"/><?php }?>
        </nav>
        </div>
        </div>
      </div>
    </div>
  </div>
  <div id="spacer">&nbsp;</div><?php }?>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr valign="top"><?php if($options['left_col']){ ?>
      <td width="220">
      	<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <?php if($options['plugins']){ ?>
          <tr>
            <td>
              <div id="plugin_col_onvan" color="<?php echo $amin_color; ?>" class="defult">
                <div class="_div2">
                  <div class="_div3">
                    <div class="onvan"><?php echo lang(333); ?></div>
                    <div class="neveshte">
                      <div align="center">
                        <strong><?php echo count($host); ?> <?php echo lang(333); ?></strong>
                      </div>
                       <div id="plugins_t" class="hide_table">
                        <div class="neveshte_inner">
                        <div id="sidebar">
                      	<ul id="menu_slide">
                          <?php
                          ksort($host);
                          foreach ($host as $site => $file)
                              {
                              echo '<li><span>'.$site.'</span></li>';
                              }?>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                  </div>
                  </div></div>
              <div id="spacer">&nbsp;</div>
            </td>
          </tr><?php }?>
          <?php
		  global $premium_acc, $mu_cookie_user_value;
		  if ( !empty ( $premium_acc ) || ( $mu_cookie_user_value ) )
		  {
		  ?>
          <tr>
            <td>
            
              <div color="<?php echo $amin_color; ?>" class="defult">
                <div class="_div2">
                  <div class="_div3">
              
                   <div class="onvan"><?php echo str_replace(' :','',lang(376)); ?></div>
                      
                    <div class="neveshte">
                    <?php
					  if ( !empty ( $premium_acc ) )
					  {
						  $premium_count = 0;
						  foreach ( $premium_acc as $serverName => $value )
						  {
							  $premium_count++;
						  }
						  echo '<div align="center"><strong>'.$premium_count.' '.str_replace(' :','',str_replace('s','(s)',lang(376))).'</strong></div>';
						  echo '<div class="neveshte_inner">';
						  foreach ( $premium_acc as $serverName => $value )
						  {
							  echo '{ <label title="'. strtoupper(str_replace( '_', '.', $serverName )) .'">'. str_replace( '_', '.', $serverName ) .'</label><br />';
						  }echo '</div>';
					  }
					  
					  if ( $mu_cookie_user_value )
					  {
						  echo '<span class="plugincollst">{ Megaupload</span><br />';
					  }
		  ?>
                    </div>
                  
                  </div>
                </div>
              </div>
              
            </td>
          </tr><?php }?>
				<?php if($options['tools']){ ?>
          <tr>
            <td><?php if($premium_count>0){ ?><div id="spacer">&nbsp;</div><?php }?>
              <div color="<?php echo $amin_color; ?>" class="defult">
                <div class="_div2">
                  <div class="_div3">
                    <div class="onvan">Tools</div>
                    <div class="neveshte">
                    <div class="neveshte_inner" id="tools"><nav>
                    <?php					
					if(file_exists(ROOT_DIR.'\mtn.php') || file_exists(ROOT_DIR.'/mtn.php')){ ?>
                    <input type="button" value="Movie Thumbnailer" onclick="window.open('mtn.php');return false;" /><br /><?php }?>
                    <?php					
					if(file_exists(ROOT_DIR.'\audl.php') || file_exists(ROOT_DIR.'/audl.php')){ ?>
                    <input type="button" value="<?php echo lang(334); ?>" onclick="window.open('audl.php');return false;"/><br />
                    <?php }?>
                    <?php					
					if(file_exists(ROOT_DIR.'\auul.php') || file_exists(ROOT_DIR.'/audl.php')){ ?>
                    <input type="button" value="<?php echo lang(335); ?>" onclick="window.open('auul.php');return false;"/> <br><?php }?>
                    
                    <input id="notes" type="button" value="<?php echo lang(327); ?>" onclick="javascript:openNotes();"/>
                    <?php if(file_exists(ROOT_DIR.'\md5.php') || file_exists(ROOT_DIR.'/md5.php')){ ?><br />
                    <input id="mdfive" type="button" value="Change MD5" onclick="window.open('md5.php');return false;"/><?php } ?></nav><div style="height:5px">&nbsp;</div>
                    </div>
                    </div>
                  
                  </div>
                </div>
              </div>
            </td>
          </tr><?php }?>
        </table>
        
      </td>
      <td width="15">&nbsp;</td><?php }?>
      <td>
          <div color="<?php echo $amin_color; ?>" rel="tb0" class="defult tb0" >
            <div class="_div2">
              <div class="_div3">
                <div class="onvan"><span id="onvan">Transload</span></div>
                <div class="neveshte">
                  <span id="content">                
		<!--  ///////////////////////////////////////////////////////////////////////////   -->
        <form action="<?php echo $PHP_SELF; ?>" name="transload" method="post"<?php if ($options['new_window']) { echo ' target="_blank"'; } ?>>
          <div id="tb1">
                <div class="onvan hide_table">Transload</div>
                
                <strong><?php echo lang(207); ?></strong>
                  <div class="neveshte_inner">
                  <table width="100%" border="0" cellspacing="5" cellpadding="0">
                    <tr>
                      <td align="center">
                      <input title="Past your link here" required id="link" name="link" tabindex="1" type="text" onBlur="fadeinout(link);" placeholder="Past your link here..." value="">
                      </td>
                      <td rowspan="2" width="30" valign="top">
                      <input id="transload" tabindex="2" class="transload" value="<?php echo lang(209); ?>" type="<?php echo ($options['new_window'] && $options['new_window_js']) ? 'button" onclick="new_transload_window();' : 'submit'; ?>" <?php if($options['referer']){echo 'style="padding:25px 20px"';} ?>/>
                      </td>
                    </tr>
                    <?php if($options['referer']){ ?>
                    <tr>
                      <td align="center"><input title="Past Referer here, if any?"  name="referer" value="" tabindex="1" type="text" placeholder="<?php echo lang(208); ?>..." ></td>
                    </tr><?php }?>
                  </table>
                  </div>
             </div>
                  
              
		  <?php if($options['setting']){ ?>
          <!-- Options and Setting	 hide_table -->
          
          <div id="tb2" class="hide_table">
               <div class="onvan hide_table"><?php echo str_replace('Options',' Options',lang(214)).' / '.lang(330); ?></div>
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr valign="top">
                    <td width="5"><table width="100%" border="0" cellpadding="0" cellspacing="5">
                      <tr>
                        <td align="left"><label>
                          <input type="checkbox" name="dis_plug" />
                          <strong><?php echo lang(215); ?></strong></label></td>
                      </tr><?php if($options['some_settings']){ ?>
                      <tr>
                        <td align="left"><label>
                          <input id="ytube_mp" type="checkbox" name="ytube_mp" <?php echo isset($_POST['yt_fmt']) ? ' checked="checked"' : ''; ?> />
                          <?php echo lang(216); ?></label>
                          <table width="100%" border="0" id="ytubeopt" class="hide_table PO_in">
                            <tr>
                              <td colspan="2" style="white-space: nowrap;"><label><input type="checkbox" name="ytdirect" />
                                <?php echo lang(217); ?></label></td>
                            </tr>
                            <tr>
                              <td align="right" width="50"><?php echo lang(218); ?></td>
                              <td align="left"><select name="yt_fmt" id="yt_fmt">
                                <option value="highest" selected="selected"><?php echo lang(219); ?></option>
                                <option value="38"><?php echo lang(377); ?></option>
                                <option value="37"><?php echo lang(228); ?></option>
                                <option value="22"><?php echo lang(227); ?></option>
                                <option value="45"><?php echo lang(225); ?></option>
                                <option value="35"><?php echo lang(223); ?></option>
                                <option value="44"><?php echo lang(389); ?></option>
                                <option value="34"><?php echo lang(222); ?></option>
                                <option value="43"><?php echo lang(224); ?></option>
                                <option value="18"><?php echo lang(226); ?></option>
                                <option value="5"><?php echo lang(221); ?></option>
                                <option value="17"><?php echo lang(220); ?></option>
                              </select></td>
                            </tr>
                          </table></td>
                      </tr>
                      <tr>
                        <td align="left"><label>
                          <input type="checkbox" id="cookieuse" name="cookieuse" />
                          <?php echo lang(235); ?></label>
                          <table width="100%" border="0" id="cookieblock" class="hide_table PO_in">
                            <tr>
                              <td align="right" width="50"><small><?php echo lang(236); ?>:</small></td>
                              <td align="left"><input type="text" name="cookie" id="cookie" value="" /></td>
                            </tr>
                          </table>
                        </td>
                      </tr><?php }?>
                    </table></td>
                    <td width="50%"><table width="100%" border="0" cellpadding="0" cellspacing="5">
                      <tr>
                        <td align="left"><label>
                          <input type="checkbox" name="premium_acc" id="premium_acc" <?php if (count($premium_acc) > 0) print ' checked="checked"'; ?> />
                          <strong><?php echo lang(249); ?></strong></label>
                          <table width="100%" border="0" id="premiumblock" class="hide_table PO_in">
                            <tr>
                              <td align="right" width="50"><small><?php echo lang(250); ?>:</small>&nbsp;</td>
                              <td align="left"><input type="text" name="premium_user" id="premium_user" value="" /></td>
                            </tr>
                            <tr>
                              <td align="right"><small><?php echo lang(251); ?>:</small>&nbsp;</td>
                              <td align="left"><input type="password" name="premium_pass" id="premium_pass" value="" /></td>
                            </tr>
                          </table></td>
                      </tr><?php if($options['some_settings']){ ?>
                      <tr>
                        <td align="left"><label>
                          <input type="checkbox" name="mu_acc" id="mu_acc"<?php if ($mu_cookie_user_value) print ' checked="checked"'; ?> />
                          <?php echo lang(232); ?></label>
                          <table width="100%" border="0" id="mupremiumblock" class="hide_table PO_in">
                            <tr>
                              <td align="right" width="50"><small><?php echo lang(233); ?>: </small></td>
                              <td align="left"><input type="text" name="mu_cookie" id="mu_cookie" value="" /></td>
                              </tr>
                          </table></td>
                      </tr>
                      <tr>
                        <td align="left"><label>
                          <input type="checkbox" name="domail" id="domail" />
                          <?php echo lang(237); ?></label>
                          <table width="100%" border="0" class="PO_in hide_table" id="emailtd">
                            <tr>
                              <td align="right" width="50" valign="top" style="padding-top:10px"><small><?php echo lang(238); ?>: </small></td>
                              <td align="left"><input type="text" name="email" id="email" /><br>
                                <label><input type="checkbox" name="split" id="splitchkbox"/>
                                <?php echo lang(239); ?></label>
                                      <table width="100%" border="0" id="methodtd" class="hide_table PO_in">
                                        <tr>
                                          <td align="right" width="50"><small><?php echo lang(240); ?>: </small></td>
                                          <td align="left"><select name="method" class="PO_in">
                                            <option value="tc"><?php echo lang(241); ?></option>
                                            <option value="rfc"><?php echo lang(242); ?></option>
                                            </select></td>
                                        </tr>
                                        <tr>
                                          <td align="right"><small><?php echo lang(243); ?>: </small></td>
                                          <td align="left"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                            <tr>
                                              <td><input type="text" name="partSize" size="2" value="10" /></td>
                                              <td width="10">&nbsp;</td>
                                              <td width="20" align="right"><?php echo lang(244); ?></td>
                                            </tr>
                                          </table></td>
                                        </tr>
                                      </table></td>
                                  </tr>
                                </table></td>
                      </tr>
                      <tr <?php echo (!$options['download_dir_is_changeable'] ? ' class="hide_table"' : '');?>>
                        <td align="left"><label>
                          <input type="checkbox" name="saveto" id="saveto"<?php if ($mu_cookie_user_value) print ' checked="checked"'; ?> />
                          <?php echo lang(252); ?></label>
                          <table width="100%" border="0" id="path" class="hide_table PO_in">
                            <tr>
                              <td align="right" width="50"><small><?php echo lang(253); ?>: </small></td>
                              <td align="left"><input type="text" name="path" value="
							  <?php if(substr($options['download_dir'], 0, 6) != "ftp://"){$pathamin = realpath(DOWNLOAD_DIR);}else{$pathamin = $options['download_dir'];}echo $pathamin; ?>" /></td>
                              </tr>
                          </table></td>
                      </tr><?php }?>
                    </table></td>
                  </tr>
                  </table>
                  </div>
                 <?php }?>
          </form>  
          <?php if($options['server_files']){ ?>
          <!-- Server Files -->
          <div id="tb3" class="hide_table">
                <div class="onvan hide_table"><?php echo lang(331); ?></div>                  
                <div align="center" id="server_files">
                	<?php
					  _create_list();
					  $all_act_files_exist = false;
						if ((isset($_GET["act"]) || isset($_POST["act"])) && @$_GET["act"] !== 'files') {
						  if ($options["disable_actions"]) { echo lang(328)."<br /><br />"; }
						  elseif ($_GET['act'] == 'list') { $all_act_files_exist = true; }
						  elseif ((!is_array($_GET['files']) || count($_GET['files']) < 1) && (!is_array($_POST['files']) || count($_POST['files']) < 1)) {
							  echo '<div class="neveshte_inner_error" title="Click to Hide!" align="center"><strong>';
							echo lang(138)."</strong></div>";
						  }
						  else {
							$all_act_files_exist = true;
							foreach($_GET["files"] as $v) {
							  $file = $list[$v]['name'];
							  if (!is_file($file)) {
								if ($options['2gb_fix'] && in_array($_GET['act'], array('delete', 'delete_go')) && file_exists($file) && !is_dir($file) && !is_link($file)) {
								  $size_time = file_data_size_time($file);
								}
								else { $size_time = false; }
							  }
							  if ($size_time === false) {
								$all_act_files_exist = false;
								echo '<div class="neveshte_inner_error" title="Click to Hide!" align="center"><strong>';
								echo sprintf(lang(64),htmlentities($file)).'</strong></div>';
								break;
							  }
							}
						  }
						}
					  
					  require_once(CLASS_DIR."options.php");
					  if($list)
						{
						if ($options['show_all'] === true)
						  {
						  unset($Path);
						  }
						?>
                         <form action="<?php echo $PHP_SELF; ?>" name="flist" method="post">
                        <table class="neveshte_inner" width="100%" border="0" cellspacing="5" cellpadding="0" style="margin-bottom:8px;">
                        <tr><?php if(!$options['disable_actions']){ ?>
                          <td width="25%" valign="top"><?php echo renderActions(); ?></td>
						  <?php }?>
                          <td align="center" width="50%" valign="top" style="padding-top:9px">
                            <label><strong id="flist_match_text"><?php echo lang(384); ?></strong></label> | <label><strong onClick="javascript:setCheckboxes(2);"><?php echo lang(258); ?></strong></label>
                            <table width="100%" border="0" id="flist_match_hitems" class="hide_table PO_in">
                                <td align="left" width="80">
                                <label><input type="checkbox" id="flist_match_ins" checked="checked" /><small><?php echo lang(386); ?></small></label>
                                </td>
                                <td align="left" width="85%"><input type="text" id="flist_match_search" onkeypress="javascript:if(event.keyCode==13){flist_match();}" onKeyUp="flist_match();" onFocus="flist_match();" onBlur="flist_match();" />
                                </td>
                                </table>
                          </td>
                          <td width="25%" align="center" valign="top" style="padding-top:9px"><?php
                                if ($options['show_all'] === true) {
                              ?>
                              <label><strong onClick="javascript:showAll();"><?php echo lang(259); ?>&nbsp;<script type="text/javascript">if(getCookie("showAll") == 1)
                                  {
                                  document.write("<?php echo lang(260); ?>");
                                  }
                                else
                                  {
                                  document.write("<?php echo lang(261); ?>");
                                  }
                                </script>
                            </strong></label><?php }else{echo '&nbsp;';}?></td>
                          
                        </tr>
                      </table>				                   
                      	<?php
						if($list)
                          {
                          $total_files = 0;
                          foreach($list as $key => $file)
                            {
                            $total_files++;
							}
						  }
							 ?>
                        <table cellpadding="5" cellspacing="0" width="100%" class="filelist" align="center">
                        <tr align="center">
                        <td align="left" width="20"><input title="Select/Deselect All" id="setCheckboxesAll" type="checkbox" /></td>
                        <td align="left" class="sorttable_alpha"><b><?php echo lang(262); ?></b></td>
                        <td width="120"><b><?php echo lang(263); ?></b></td>
                        <?php 
						if($total_files>13){echo
                        '<td width="10">&nbsp;</td>';
						}
						?>
                        </tr>
                        </table>
                        <div style="position:relative; padding:1px 0px;">
                        <div style="overflow:auto; height:auto; max-height:450px;">
                        <table id="table_filelist" cellpadding="5" cellspacing="0" width="100%" align="center">
                        <tbody>
                        <?php
                          }
                        else
                          {
                          echo '<div class="neveshte_inner" align="center">'.lang(266).'<br>';
                          if ($options['show_all'] === true)
                            {
                            unset($Path);
                            ?>
                        <label><strong onClick="javascript:showAll();"><?php echo lang(259).' '; ?>
                        <script type="text/javascript">
                        if(getCookie("showAll") == 1)
                          {
                          document.write("<?php echo lang(260); ?>");
                          }
                        else
                          {
                          document.write("<?php echo lang(261); ?>");
                          }
                        </script></strong></label><?php echo '</div>'?>
                        <?php
                            }
                          }
                        if($list)
                          {
                          $total_files = 0;
                          $filecount = 0;
                          foreach($list as $key => $file)
                            {
                            if (($size_time = file_data_size_time($file["name"])) === false) { continue; }
                            $total_files++;
                            $total_size+=$size_time[0];
                        ?>
                        <tr title="<?php $link_file_ax = strtolower(substr(link_for_file($file["name"], TRUE),strlen(link_for_file($file["name"], TRUE))-4)); if( $link_file_ax == '.jpg' || $link_file_ax == '.png' || $link_file_ax == '.gif' || $link_file_ax == 'jpeg'){echo "<div align='center'><img src='".link_for_file($file["name"], TRUE)."' width='200' style='opacity:.9; border-radius: 8px;'></div>";} echo '<div class=PO_in><b>'.lang(104).':</b> '.substr($file["name"],strlen($pathamin)+1) ?></div><div class=PO_in><b><?php echo lang(265); ?>:</b>
                        <?php echo date("d/m - H:i:s", $file["date"]);?>
						<?php $delete_delay = $options['delete_delay'];
						if($delete_delay > 0){ ?>
                         &nbsp;&nbsp;&nbsp;<span class=red><b>Expired:</b> <?php
						 echo date("d/m - H:i:s", $file["date"] + $delete_delay) ; };?></span></div>" align="center" onmousedown="checkFile(<?php echo $filecount; ?>); return false;">
                        <td align="left" width="20">
                        <input onmousedown="checkFile(<?php echo $filecount;?>); return false;" id="files<?php echo $filecount; ?>" type="checkbox" name="files[]" value="<?php echo $file["date"]; ?>" /></td>
                        <td align="left"><?php echo link_for_file($file["name"], FALSE); ?></td>
                        <td width="120"><?php echo $file["size"]; ?></td>                        
                        </tr>
                        <?php
                            $filecount ++;}
                        ?>
                        </tbody>
                        </table>
                        </div>
                        </div>
                         <?php
                          if (($total_files > 1) && ($total_size > 0)) {                           
                          ?>
                         <table cellpadding="5" cellspacing="0" width="100%" class="filelist" align="center">
                        <tr align="center">
                        <td align="left" width="20">&nbsp;</td>
                        <td align="left" class="sorttable_alpha"><b><?php echo 'Total: '.$total_files; ?></b></td>
                        <td width="120"><b><?php echo bytesToKbOrMbOrGb($total_size); ?></b></td>
                        <?php
						if($total_files>13){echo
                        '<td width="10">&nbsp;</td>';
						}
						?>
                        </tr>
                        </table>
                        
                        <?php
						}
						unset($total_files);
                          }
                        ?>
                  </form>
                </div>
              </div>
            <?php }?>
          
          <?php if($options['admin_mail']){ ?>
          <!---  Contact Form -->
          <div id="tb4" class="hide_table">
                      <div class="onvan hide_table">Contact us</div>
                      <span id="contact">
                    <div align="center"><?php include(CLASS_DIR.'contact_us.php'); ?></div>
						  <form action="<?php echo $PHP_self ?>" method="post" name="contact">
                          <table align="center" width="100%" border="0" cellspacing="5" cellpadding="0">
                            <tr valign="top">
                              <td width="50%">
                              <table width="100%" border="0" class="PO_in">
                            <tr>
                              <td align="left"><input title="Your Name" name="contact_name" required type="text" tabindex="3" placeholder="Your Name:" maxlength="30" value="<?php echo $_COOKIE["contact_name"]; ?>" /></td>
                            </tr>
                            <tr>
                              <td><input name="contact_mail" maxlength="50" required title="Your E-mail" type="email" tabindex="4" placeholder="Your E-mail:" value="<?php echo $_COOKIE["contact_mail"]; ?>" /></td>
                            </tr>
                            </table>
                              </td>
                              <td rowspan="2" valign="top" class="PO_in" id="textarea_td">
                              <textarea id="textarea_mess" title="Message" name="contact_msg" required style="height:125px" tabindex="5" placeholder="Message:"></textarea></td>
                            </tr>
                            <tr valign="top">
                              <td align="left">
                              <table width="100%" border="0" class="PO_in">
                            <tr>
                              <td align="right" width="100" id="captcha_image" title="Captcha"></td>
                              <td align="left"><input name="captcha" title="Enter 5 digit numbers"  placeholder="Enter 5 charecters seen in picture" type="text" required width="5" maxlength="5" tabindex="6"/></td>
                            </tr>
                            </table></td>
                            </tr>
                           	 <tr valign="top">
                              <td>
                              <label>
                          <input type="checkbox" id="checkbox_plugin_report"/>
                          Report not working plugin / Donate Premium account</label>
                          <table width="100%" border="0" id="Plugin_report" class="hide_table PO_in">
                            <tr>
                              <td align="right" width="40"><label for="contact_plugin"><small>Plugin / Acc:</small></label></td>
                              <td align="left"><input type="text" name="contact_plugin" value="" placeholder="Filesonic.com" title="e.g. Filesonic.com" /></td>
                            </tr>
                          </table>
                              </td>
                            </tr>
                            <tr><td colspan="2" align="center"><input tabindex="7" type="submit" value="Send" style="width:100px"/></td></tr>
                          </table>
					  </form>
                  </span>
		  <?php }?>
               </div> 
               </span>
      </div>
            </div>
          </div>
          </div><?php if($options['latest_news']) { ?>
          <div id="spacer" rel="latestnews">&nbsp;</div>
          <div color="<?php echo $amin_color; ?>" id="latestnews" class="defult">
                <div class="_div2">
                  <div class="_div3">
                   <div class="onvan">Latest News</div>
                    <div class="neveshte">
					<?php $newsHandler->displayNews(); ?>
                    </div>
                  </div>
                </div>
              </div><?php }?>
          </td>
    </tr>
  </table>
  <?php
  if($_POST['contact_name'])
	  {
		  echo '<script type="text/javascript">switchCell_amin(4);$(\'#captcha_image\').attr(\'background\',\'captcha.php\');</script>';
	  }
	elseif($_GET["act"])
	  {
		echo '<script type="text/javascript">switchCell_amin(3);</script>';
	  }
	else
	  {
		echo '<script type="text/javascript">'."$('#navcell1').addClass('selected');</script>";
	  }
	
  ?>
  
   <?php
if ($options['server_info'] || $options['file_size_limit'] > 0 || (is_numeric($delete_delay) && $delete_delay > 0)){ ?>
  <!--               file size limit               -->
  <script type="text/javascript">
	var show = 0;
	var show2 = 0;
	</script><div id="spacer">&nbsp;</div>
  <div color="<?php echo $amin_color; ?>" class="defult">
    <div class="_div2">
      <div class="_div3">
       <div class="onvan">Server information</div>
        <div class="neveshte">    
        <table width="100%" border="0" cellspacing="0" cellpadding="0" style="margin-bottom:5px;">
          <tr>
          <?php
			  if ($options['file_size_limit'] > 0 || $delete_delay = $options['delete_delay']> 0){ ?>
  			
          <td width="50%"><strong>Laws</strong>
          <div class="neveshte_inner">
          	<?php
			  if ($options['file_size_limit'] > 0) {
				  echo lang(337).' <b>' . bytesToKbOrMbOrGb ( $options['file_size_limit']*1024*1024 ) . '</b><br />';
			  }
			  ?>
			  <?php
			  if ( $delete_delay > 0){
				  if($delete_delay > 3600){
					  $ddelay = round($delete_delay/3600, 1);
					  print lang(282).': <b>'.$ddelay.'</b> '.lang(283);
				  }else{
					  $ddelay = round($delete_delay/60);
					  print lang(282).': <b>'.$ddelay.'</b> '.lang(284);
				  }
			  }
			  ?>
          </div></td>
          <td width="10">&nbsp;</td>      
   <?php } if ($options['stats']){?> <td>
   <?php require_once(CLASS_DIR."counter.php"); ?>
   </td><?php }?>
          </tr>
        </table>
        
			  <?php if($options['server_info']) {
                  ob_start();
              ?>
              <?php require_once(CLASS_DIR."sinfo.php"); ?>
              <?php
                if ($options['ajax_refresh']) {
              ?>
              <script type="text/javascript">refreshStats();</script>
              <?php
                }
                  ob_end_flush();
              }
              ?>
        </div>
        </div>
      </div>
    </div>
  </div>
  <?php }?>
</div>
<div align="center" id="footer" role="contentinfo">
<?php
$emsal = date(Y);
$emsal == 2011 ? $tarikhe_copy = '.' : $tarikhe_copy = '-'.$emsal;

echo '&copy; Copyright <a href="" title="'.$options['site_title_description'].'">'.$options['site_title'].'</a> 2011'.$tarikhe_copy.' | All Rights Reserved';
?>
<br />
<!--
THIS OPEN SOURCE PROJECT IS UNDER LICENSE OF PHP LICENCE & SOURCEFORGE.NET.
IF YOU REMOVE BOTTOM CODES, YOU WILL PROBATE UNDER CONTINUATION OF FEDERAL!
SO, YOU CANNOT CHANGE ANYTHINGS HERE.
 --> 
<?php 
 echo '{<a href="https://sourceforge.net/projects/enterprise-rl/" target="_blank" title="Enterprise is a new Rapidleech script template based on HTML5, CSS3 and jQuery.">Enterprise</a>} Template by <a href="http://www.amingholami.com" alt="AminGholami.com" target="_blank" >AminGholami.com </a> <span> </span>
</div>';
?>
</div>