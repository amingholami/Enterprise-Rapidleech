<?php 
// color progressbar
function rang_class($percent){
if ($percent >= 0  ) { $rang_class = 'raftez'; } 
if ($percent > 19.8) { $rang_class = 'raftea'; } 
if ($percent > 36.7) { $rang_class = 'rafteb'; }
if ($percent > 64.6) { $rang_class = 'raftec'; }
if ($percent > 80.3) { $rang_class = 'rafted'; }
return $rang_class;
}
?>
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="ss-cpu-table">
                <tr>
                <td align="left" valign="top" width="50%">
                <!-- Start Server Space Info -->
                	<strong><?php echo lang(275); ?></strong>
                  <div class="neveshte_inner">                  
                  <table width="100%" border="0" cellspacing="5" cellpadding="0">
                    <tr align="center">
                      <td><?php echo lang(278); ?> = <b><output id="diskspace"><?php echo ZahlenFormatieren($insgesamt); ?></output></b></td>
                      <td><?php echo lang(276); ?> = <b><output id="inuse"><?php echo ZahlenFormatieren($belegt); ?></output></b></td>
                      <td><?php echo lang(277); ?> = <b><output id="freespace"><?php echo ZahlenFormatieren($frei); ?></output></b></td>                      
                    </tr>
                    <tr align="center">
                     <td colspan="3" title="Host / Disk Space Usage Percent">
                     <?php if (extension_loaded('gd') && function_exists('gd_info')) { ?>
                     <table width="100%" border="0" cellspacing="0" cellpadding="0" id="sinfo">
                      <tr align="left" valign="middle" help>
                        <td id="progress" rel="rafte" anim class="<?php echo rang_class($prozent_belegt); ?>" align="center" style="width:<?php echo round($prozent_belegt,"2"); ?>%">
                        <b><output id="inusepercent"><?php echo round($prozent_belegt,"3"); ?></output>%</b><output class="<?php echo rang_class($HSUP=round($total_size*100/$belegt,2)); ?>" id="HSUP" style="width:<?php echo $HSUP; ?>%;"><?php echo $HSUP > 30? $HSUP.'%':''; ?></output>
                        </td>
                      </tr>
                    </table>

                <?php } ?>
                     </td>
                    </tr>
                  </table>                 
                </div>                
				</td><td width="10">&nbsp;</td>
                  <td valign="top">
                <!-- Start CPU Info -->
                <strong><?php  echo lang(279) ?></strong>
                <div class="neveshte_inner">
                <table width="100%" border="0" cellspacing="5" cellpadding="0">
                  <tr align="center">
                   <?php if (extension_loaded('gd') && function_exists('gd_info')) { ?>
                    <td>
                    <?php
					  $cpu_percent = 0;
					  if($cpulast)
					  {
						  $cpu_percent = round($cpulast,"3");
						  }else if($cpu->loadpercentage)
						  {
							  $cpu_percent = round ( $cpu->loadpercentage, "3" );					  
							  }if ($cpu_string === -1){echo lang(136).' = <b>N/A<b>';}
                        else { $cpu_percent<10 ? '0'.$cpu_percent : $cpu_percent;echo lang(136).' = <b><span id="cpuload">'.$cpu_percent.'</span>%<b>'; 
						}?>
                    </td>
                    <td> <!--  server time:  -->
                  <?php echo lang(280); ?>: 
                  <b><output id="server_amin"></output></b>
                  </td>
                    <td><?php echo lang(281); ?>: 
                  <b><output id="clock_amin"></output></b></td>
                  </tr>
                  <tr>
                    <td colspan="3" title="CPU Load Percent">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" id="sinfo">
                          <tr valign="middle" align="left" id="cpu_table" help>
                            <td rel="rafte" anim class="rafte <?php echo rang_class($cpu_percent); ?>" align="center" style="width:<?php echo $cpu_percent; ?>%" name="cpupercent" id="cpupercent" ><b><?php if ($cpu_string === -1) { echo '</b></td><td align="center"><b>'.lang(135); }else { echo '<output id="cpupercent_inner">'.$cpu_percent.'</output>%'; }?></b></td>
                      </tr>
                    </table></td>
                  </tr>
                </table>
                
                <?php }?>
                  </div>
                
                </td>
                </tr>
              </table>
                <!-- End CPU Info -->
<script type="text/javascript"> 
				//<![CDATA[
					function goforit(){
						setTimeout("getthedate()",1000);
						timeDiff('<?php echo date('Y'); ?>','<?php echo date('n'); ?>','<?php echo date('j'); ?>','<?php echo date('G'); ?>','<?php echo date('i'); ?>','<?php echo date('s'); ?>','dd-mm-yyyy');
					}
					$(document).ready(function() {
						goforit();
					})
				//]]> 
				</script>
                