<br />
<div id="tip"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" id="sinfo">
  <tr align="left" valign="middle">
    <td colspan="3" style="width:0;" id="progress" rel="rafte" class="rafted" align="center"><b id="percent">0%</b></td>
  </tr>
  </table>
  <table border="0" width="100%">
    <tr>
      <td align="left" width="100"><b id="received">0 MB</b></td>
      <td>&nbsp;</td>
      <td align="right" width="100"><b id="speed">0 kb/s</b></td>
    </tr>
  </table>
<div id="resume" align="center"></div>
</div>
<div id="info_ezafi" class="hide_table">
<div align="center" class="neveshte_inner_success" title="Click to Hide!"><strong>Transloaded Successfully!</strong></div>
<script type="text/javascript">
/* <![CDATA[ */
function pr(percent, received, speed, class_rang)
{
  document.title = percent + '% Downloaded';
  $('#progress').animate({width:percent+"%"},{queue:false,duration:200});
  document.getElementById("percent").innerHTML =  percent + '%';
  document.getElementById("received").innerHTML = received;
  document.getElementById("speed").innerHTML = speed +' kb/s';
  document.getElementById('progress').className = class_rang;
  return true;
}

function mail(str, field)
{
  document.getElementById("mailPart." + field).innerHTML = str;
  return true;
}
/* ]]> */
</script>
                        