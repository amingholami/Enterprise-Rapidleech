<?php 
//u can add here every php code

?>
</body>
<div id="tip"></div>
</html>