<?php
@date_default_timezone_set(date_default_timezone_get());
// Contact us Captcha
$rand = substr(strtoupper(md5(rand(10000,99999))),0,5);
session_start('capcha');
if(!isset($_POST['captcha']))
{
  $_SESSION['capcha'] = $rand;
}
// Change color schem in browser...
if(!empty($_COOKIE['amin_color']))
{
  $amin_color = $_COOKIE['amin_color'];
}
// if Not set any color?
elseif(empty($_COOKIE['amin_color']))
{
  setcookie('amin_color',$options['default_color'],time()+60*60*24*365);
  $amin_color = $options['default_color'];
}

if ($_REQUEST ["contact_name"])
{
	setcookie ( "contact_name", $_REQUEST ["contact_name"],time()+60*60*24*365);
}
if ($_REQUEST ["contact_mail"])
{
	setcookie ( "contact_mail", $_REQUEST ["contact_mail"],time()+60*60*24*365);
}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title><?php
if (!isset($page_title)) {
	echo $options['site_title'].' | '.$options['site_title_description'];
} else {
	echo htmlentities($page_title);
}
?></title>
<link href="templates/<?php echo $options['template_used']?>/images/amin_style.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
var php_js_strings = []; php_js_strings[87] = " <?php echo lang(87); ?>";
</script>
<script type="text/javascript" src="classes/js.js"></script>
<script type="text/javascript" src="templates/<?php echo $options['template_used']?>/images/amin_js.js"></script>
<script language="JavaScript" type="text/javascript">
hide_error();hide_success();
</script>
<?php
if ($options['ajax_refresh']) { echo '<script type="text/javascript" src="classes/ajax_refresh.js"></script>'.$nn; }
?>
<!--[if lte IE 8]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<meta name="keywords" content="">
<meta name="description" content="">

</head>
<body>
  <div id="branding" role="banner">
   <header>
        <h1><a href="<?php echo $PHP_self ?>" title="<?php echo $options['site_title_description']; ?>" ><?php echo $options['site_title']; ?></a></h1>
        <div id="discr"><?php echo $options['site_title_description']; ?></div>
   </header>
  </div>
  <div id="body">
<noscript>
<div color="<?php echo $amin_color; ?>" class="defult"><div class="_div2"><div class="_div3"><div class="onvan">JavaScript Error!</div><div class="neveshte"><div class="neveshte_inner_error" align="center"><strong>This page won't work without JavaScript, please enable JavaScript and refresh the page.</strong></div></div></div></div></div><div id="spacer">&nbsp;</div></noscript>