<?php

##   15/05/2011 

####### Account Info. ###########

$easy_login = ''; // Set your easy-share user
$easy_pass = ''; // Set your easy-share password

##############################

$filefactory_login = ''; //Set your FileFactory user
$filefactory_pass = ''; //Set your FileFactory password

##############################

$fileserve_login = ''; //Set your fileserve id (login)
$fileserve_pass = ''; //Set your fileserve password

##############################

$filesonic_login = ''; //Set your filesonic.com user
$filesonic_pass = ''; //Set your filesonic.com password

##############################

$freakshare_member_login = ''; //Set your freakshare member email id (login)
$freakshare_member_pass = ''; //Set your freakshare member password

##############################

$freakshare_premium_login = ''; //Set your freakshare Premium email id (login)
$freakshare_premium_pass = ''; //Set your freakshare Premium password

##############################

$hellshare_login = ''; //  Set your Hellshre username
$hellshare_pass = ''; //  Set your Hellshare username

##############################

$hotfile_username= ''; //  Set your HotFile username
$hotfile_password= ''; //  Set your HotFile password

##############################

$letitbit_login = ''; //Set your letitbit.net email id (login)
$letitbit_pass = ''; //Set your letitbit.net password

##############################

$megashares_login = ''; //Set your megashares email id (login)
$megashares_pass = ''; //Set your megashares password
$uploadFileCategory = ''; //Set megashares upload-File-Category

##############################

$oron_login = ''; //Set your Oron username
$oron_pass = ''; //Set your Oron username

##############################

$stagevu_login = ''; //  Set your stagevu.com username
$stagevu_pass = ''; //  Set your stagevu.com password

##############################

$turbobit_login = ''; //  Set your turbobit login
$turbobit_pass = '';  //  Set your turbobit pass

##############################

$uploading_login = ''; //  Set your uploading.com username
$uploading_pass = ''; //  Set your uploading.com password

##############################

$megaupload_login = ''; // MegaUpload Member/Premium login
$megaupload_pass = ''; // MegaUpload Member/Premium password
$megaupload_desc= '';  // File Descriptions, You can specify your manual own description or Keep it blank to auto-generate description from file name.
##########################################

$megavideo_login = ''; //Set your megavideo.com login
$megavideo_pass = ''; //Set your megavideo.com password
$megavideo_channel = '24'; //  Set your channel, see details below
// 1 for Arts & Animations, 2 for Autos & Vehicles, 23 for Comedy
//  24 for Entertainment, 10 for Music, 25 for News & Blogs
//  22 for People, 15 for Pets & Animals, 26 for Science & Technology
//  17 for Sports, 19 for Travel & Places, 20 for Video Games

##########################################

$rapidsharemb_login = ''; //Set your RapidShare username
$rapidsharemb_pass = ''; //Set your RapidShare password

##############################

$duckload_username=''; //  Set your duckload username
$duckload_password=''; //  Set your duckload password

##############################

$videobb_login = ''; //Set your videobb email id (login)
$videobb_pass = ''; //Set your videobb password

##############################

$filereactor_login = ''; //  Set your Filereactor username
$filereactor_pass = ''; //  Set your FileReactor password

##############################

$bitshare_login = ''; //Set your bitshare.com user
$bitshare_pass = ''; //Set your bitshare.com password

##############################

$hostingbulk_login = ''; // HostingBulk.com User
$hostingbulk_pass = ''; // HostingBulk.com Password

##############################

$skipfile_login = ''; // SkipFile.com User
$skipfile_pass = ''; // SkipFile.com Password

##############################

##############################
$multiupload_login = ''; // MultiUpload.com User
$multiupload_pass = '';	// MultiUpload.com Password

#RapidShare			#Megaupload
$RSuser = '';		$MUuser = '';
$RSpass = '';		$MUpass = '';
								
$RSacc = "C";		# "C" = Collector  	# "P" = Premium		

#Uploading				#Hotfile
$UPuser = '';		$HFuser = '';
$UPpass = '';		$HFpass = '';

##################################

$shragle_login = ''; // shragle.com Username
$shragle_pass = ''; // shragle.com Password

##############################

$youtube_login = '';  // YouTube Login ID
$youtube_pass = '';  //Youtube Password

##############################

$videoweed_login = ''; //Set your videoweed.com email id (login)
$videoweed_pass = ''; //Set your videoweed.com password

##############################

$putlocker_login = '';  //Set your PutLocker Login ID
$putlocker_pass = '';  //Set your PutLocker password

##############################

$megaplus_login = ''; //Set your share.vnn.vn Login ID
$megaplus_pass = ''; //Set your share.vnn.vn Password

##############################

$usershare_login = ''; //Set your usershare Login ID
$usershare_pass = ''; //Set your usershare password

##############################

$pyramidfiles_login = ''; //Set your PyramidFiles Login ID
$pyramidfiles_pass = ''; //Set your PyramidFiles Password

##############################

$netload_login = ''; // Netload.in ID
$netload_pass = ''; // Netload.in Password

##############################

$uploaded_username = ''; //  Set you Uploaded.to username
$uploaded_password = ''; //  Set your Uploaded.to password

##############################

$uploadstation_login = ''; // Set your Uploadstation ID
$uploadstation_pass = ''; // Set your Uploadstation Password

##############################

$twitvid_login = ''; //Set your twitvidtory email id (login)
$twitvid_pass = ''; //Set your twitvidtory password
$twitvid_message = 'Watch my video on #twitvid';

##############################

$filekeen_login = ''; // filekeen.com login id
$filekeen_pass = ''; // filekeen.com password

##############################

$uploadstore_login = ''; //Set your uploadstore.net email id (login)
$uploadstore_pass = ''; //Set your uploadstore.net password

##############################

$vidxden_login = ''; // Vidxden.com login id
$vidxden_pass = ''; // Vidxden.com password

##############################

$wootly_login = ''; // gaiafile.com or wootly.com login id
$wootly_pass = ''; // gaiafile.com or wootly.com password

##############################

$userporn_login = ''; // Set your userporn.com login id
$userporn_pass = ''; // Set your userporn.com password

##############################

$vidbux_login = ''; // Set your vidbux.com login id
$vidbux_pass = ''; // Set your vidbux.com password

##############################


?>