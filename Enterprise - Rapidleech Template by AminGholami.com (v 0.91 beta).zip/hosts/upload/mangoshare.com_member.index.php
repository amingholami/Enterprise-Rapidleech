<?php 
$upload_services[]="mangoshare.com_member";
$max_file_size["mangoshare.com_member"]=1500;
$page_upload["mangoshare.com_member"] = "mangoshare.com_member.php";  
?>