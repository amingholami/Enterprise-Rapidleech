<?php 
$upload_services[]="mandamais.com";
$max_file_size["mandamais.com"]=500;
$page_upload["mandamais.com"] = "mandamais.com.php";  
?>