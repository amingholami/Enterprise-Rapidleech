<?php 
$upload_services[]="rapidshare.com";
$max_file_size["rapidshare.com"]=200;
$page_upload["rapidshare.com"] = "rapidshare.com.php";  
?>