<?php 
$upload_services[] = "megaporn.com";
$max_file_size["megaporn.com"] = 1024;
$page_upload["megaporn.com"] = "megaporn.com.php";
?>