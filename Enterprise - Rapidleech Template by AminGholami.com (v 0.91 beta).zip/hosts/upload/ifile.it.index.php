<?php
$upload_services[]="ifile.it";
$max_file_size["ifile.it"]=1000;
$page_upload["ifile.it"] = "ifile.it.php";  
?>