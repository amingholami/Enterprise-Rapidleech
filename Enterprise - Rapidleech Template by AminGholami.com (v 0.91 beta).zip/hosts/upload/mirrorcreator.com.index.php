<?php
$upload_services[]="mirrorcreator.com";
$max_file_size["mirrorcreator.com"]=200;
$page_upload["mirrorcreator.com"] = "mirrorcreator.com.php";  
?>