<?php
$upload_services[]="filekeen.com_member";
$max_file_size["filekeen.com_member"]=2000;
$page_upload["filekeen.com_member"] = "filekeen.com_member.php";  
?>