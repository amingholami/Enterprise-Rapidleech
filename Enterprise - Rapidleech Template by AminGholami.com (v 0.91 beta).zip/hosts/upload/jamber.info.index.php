<?php
$upload_services[]="jamber.info";
$max_file_size["jamber.info"]=2000;
$page_upload["jamber.info"] = "jamber.info.php";  
?>