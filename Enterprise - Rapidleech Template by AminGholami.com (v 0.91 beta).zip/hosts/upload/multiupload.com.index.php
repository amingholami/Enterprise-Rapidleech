<?php
$upload_services[]="multiupload.com";
$max_file_size["multiupload.com"]=2000;
$page_upload["multiupload.com"] = "multiupload.com.php";  
?>