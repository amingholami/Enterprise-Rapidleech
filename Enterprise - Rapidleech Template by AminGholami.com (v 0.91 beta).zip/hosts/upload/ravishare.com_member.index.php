<?php
$upload_services[]="ravishare.com_member";
$max_file_size["ravishare.com_member"]=1024;
$page_upload["ravishare.com_member"] = "ravishare.com_member.php";
?>
