<?php
$upload_services[]="files.to";
$max_file_size["files.to"]=150;
$page_upload["files.to"] = "files.to.php";  
?>