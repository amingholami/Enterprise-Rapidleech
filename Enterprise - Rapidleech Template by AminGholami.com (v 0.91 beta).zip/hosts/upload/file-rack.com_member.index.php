<?
$upload_services[]="file-rack.com_member";
$max_file_size["file-rack.com_member"]=200;
$page_upload["file-rack.com_member"]="file-rack.com_member.php";
?>