<?php
$upload_services[]="biggerupload.com";
$max_file_size["biggerupload.com"]=100;
$page_upload["biggerupload.com"] = "biggerupload.com.php";  
?>