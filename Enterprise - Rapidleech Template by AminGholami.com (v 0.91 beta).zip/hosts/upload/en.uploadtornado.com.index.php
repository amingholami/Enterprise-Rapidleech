<?php
$upload_services[]="en.uploadtornado.com";
$max_file_size["en.uploadtornado.com"]=1000;
$page_upload["en.uploadtornado.com"] = "en.uploadtornado.com.php";  
?>