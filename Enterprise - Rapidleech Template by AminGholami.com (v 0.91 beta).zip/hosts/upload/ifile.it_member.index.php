<?php
$upload_services[] = "ifile.it_member";
$max_file_size["ifile.it_member"] = 1000;
$page_upload["ifile.it_member"] = "ifile.it_member.php";  
?>