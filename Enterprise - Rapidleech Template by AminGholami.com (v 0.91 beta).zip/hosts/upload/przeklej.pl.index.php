<?php 
$upload_services[]="przeklej.pl";
$max_file_size["przeklej.pl"]=500;
$page_upload["przeklej.pl"] = "przeklej.pl.php";  
?>