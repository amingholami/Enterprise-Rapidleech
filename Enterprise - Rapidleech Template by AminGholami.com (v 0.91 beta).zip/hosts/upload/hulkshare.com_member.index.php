<?php
$upload_services[]="hulkshare.com_member";
$max_file_size["hulkshare.com_member"]=275;
$page_upload["hulkshare.com_member"] = "hulkshare.com_member.php";
?>