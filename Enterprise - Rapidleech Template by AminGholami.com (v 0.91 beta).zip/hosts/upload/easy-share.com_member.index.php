<?php 
$upload_services[] = "easy-share.com_member";
$max_file_size["easy-share.com_member"] = 1000;
$page_upload["easy-share.com_member"] = "easy-share.com_member.php";
?>