<?php
$upload_services[]="rapidspread.com";
$max_file_size["rapidspread.com"]=4000;
$page_upload["rapidspread.com"] = "rapidspread.com.php";  
?>