<?php
$upload_services[]="amonshare.com";
$max_file_size["amonshare.com"]=300;
$page_upload["amonshare.com"] = "amonshare.com.php";
?>