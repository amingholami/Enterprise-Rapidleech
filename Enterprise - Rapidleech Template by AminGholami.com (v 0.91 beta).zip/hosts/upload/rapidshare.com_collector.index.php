<?php 
$upload_services[] = "rapidshare.com_collector";
$max_file_size["rapidshare.com_collector"] = 200;
$page_upload["rapidshare.com_collector"] = "rapidshare.com_collector.php";  
?>