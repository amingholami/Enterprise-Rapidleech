<?php
$upload_services[] = "oron.com";
$max_file_size["oron.com"] = 400;
$page_upload["oron.com"] = "oron.com.php";  
?>