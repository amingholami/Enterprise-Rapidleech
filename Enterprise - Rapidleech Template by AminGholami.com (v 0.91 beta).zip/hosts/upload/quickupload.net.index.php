<?php
$upload_services[]="quickupload.net";
$max_file_size["quickupload.net"]=800;
$page_upload["quickupload.net"] = "quickupload.net.php";  
?>