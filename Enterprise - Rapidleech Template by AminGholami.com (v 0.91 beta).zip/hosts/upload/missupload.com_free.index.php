<?php
$upload_services[]="missupload.com_free";
$max_file_size["missupload.com_free"]=50;
$page_upload["missupload.com_free"] = "missupload.com_free.php";  
?>