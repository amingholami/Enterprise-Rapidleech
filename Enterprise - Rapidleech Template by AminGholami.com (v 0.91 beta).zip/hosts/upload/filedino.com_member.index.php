<?php
$upload_services[] = "filedino.com_member";
$max_file_size["filedino.com_member"] = 2000;
$page_upload["filedino.com_member"] = "filedino.com_member.php";  
?>