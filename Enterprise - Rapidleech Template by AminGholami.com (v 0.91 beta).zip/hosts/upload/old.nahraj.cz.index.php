<?php
$upload_services[]="old.nahraj.cz";
$max_file_size["old.nahraj.cz"]=250;
$page_upload["old.nahraj.cz"] = "old.nahraj.cz.php";
?>