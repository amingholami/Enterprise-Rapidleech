<?php
$upload_services[]="filesend.net_free";
$max_file_size["filesend.net_free"]=500;
$page_upload["filesend.net_free"] = "filesend.net_free.php";  
?>