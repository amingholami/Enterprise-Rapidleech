<?php
$upload_services[]="divxden.com_member";
$max_file_size["divxden.com_member"]=1000;
$page_upload["divxden.com_member"] = "divxden.com_member.php";  
?>