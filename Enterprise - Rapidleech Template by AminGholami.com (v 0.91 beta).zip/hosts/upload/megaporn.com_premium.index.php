<?php
$upload_services[]="megaporn.com_premium";
$max_file_size["megaporn.com_premium"]=1024;
$page_upload["megaporn.com_premium"] = "megaporn.com_premium.php";  
?>