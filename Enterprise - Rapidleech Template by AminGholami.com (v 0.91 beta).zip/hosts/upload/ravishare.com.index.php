<?php
$upload_services[]="ravishare.com";
$max_file_size["ravishare.com"]=512;
$page_upload["ravishare.com"] = "ravishare.com.php";
?>
