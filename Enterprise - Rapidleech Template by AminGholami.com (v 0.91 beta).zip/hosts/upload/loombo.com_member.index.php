<?php
$upload_services[]="loombo.com_member";
$max_file_size["loombo.com_member"]=1000;
$page_upload["loombo.com_member"] = "loombo.com_member.php";  
?>