<?php
$upload_services[]="enterupload.com_free";
$max_file_size["enterupload.com_free"]=250;
$page_upload["enterupload.com_free"] = "enterupload.com_free.php";  
?>