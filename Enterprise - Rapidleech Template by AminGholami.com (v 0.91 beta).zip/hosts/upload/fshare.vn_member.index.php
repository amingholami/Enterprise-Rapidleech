<?php
$upload_services[]="fshare.vn_member";
$max_file_size["fshare.vn_member"]=500;
$page_upload["fshare.vn_member"] = "fshare.vn_member.php";
?>