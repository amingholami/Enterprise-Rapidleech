<?php 
$upload_services[]="fileserve.com_member";
$max_file_size["fileserve.com_member"]=1024;
$page_upload["fileserve.com_member"] = "fileserve.com_member.php";  
?>
