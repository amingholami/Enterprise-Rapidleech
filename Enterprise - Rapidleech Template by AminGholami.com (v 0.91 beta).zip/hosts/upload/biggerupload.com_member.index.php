<?php
$upload_services[]="biggerupload.com_member";
$max_file_size["biggerupload.com_member"]=200;
$page_upload["biggerupload.com_member"] = "biggerupload.com_member.php";  
?>