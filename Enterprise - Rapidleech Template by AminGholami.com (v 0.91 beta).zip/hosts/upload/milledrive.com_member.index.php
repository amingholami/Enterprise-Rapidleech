<?php
$upload_services[]="milledrive.com_member";
$max_file_size["milledrive.com_member"]=1000;
$page_upload["milledrive.com_member"] = "milledrive.com_member.php";  
?>