<?php
$upload_services[]="novaup.com";
$max_file_size["novaup.com"]=1000;
$page_upload["novaup.com"] = "novaup.com.php";  
?>