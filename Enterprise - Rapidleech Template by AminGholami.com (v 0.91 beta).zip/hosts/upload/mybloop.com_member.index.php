<?php 
$upload_services[] = "mybloop.com_member";
$max_file_size["mybloop.com_member"] = 1000;
$page_upload["mybloop.com_member"] = "mybloop.com_member.php";  
?>