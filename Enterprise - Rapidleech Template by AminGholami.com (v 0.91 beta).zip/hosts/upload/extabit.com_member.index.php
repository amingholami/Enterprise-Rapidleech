<?php
$upload_services[]="extabit.com_member";
$max_file_size["extabit.com_member"]=2048;
$page_upload["extabit.com_member"] = "extabit.com_member.php";  
?>