<?php
$upload_services[]="movieshare.in";
$max_file_size["movieshare.in"]=1000;
$page_upload["movieshare.in"] = "movieshare.in.php";
?>
