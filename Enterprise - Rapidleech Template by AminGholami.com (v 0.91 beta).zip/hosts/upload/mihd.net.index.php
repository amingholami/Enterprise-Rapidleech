<?php
$upload_services[]="mihd.net";
$max_file_size["mihd.net"]=101;
$page_upload["mihd.net"] = "mihd.net.php";  
?>