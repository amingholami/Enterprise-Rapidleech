<?php 
$upload_services[] = "imagehaven.net";
$max_file_size["imagehaven.net"] = 3;
$page_upload["imagehaven.net"] = "imagehaven.net.php";
?>