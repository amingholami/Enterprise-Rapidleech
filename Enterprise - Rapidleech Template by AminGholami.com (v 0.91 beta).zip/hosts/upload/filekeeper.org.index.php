<?php
$upload_services[]="filekeeper.org";
$max_file_size["filekeeper.org"]=100;
$page_upload["filekeeper.org"] = "filekeeper.org.php";  
?>