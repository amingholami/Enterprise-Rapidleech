<?
$upload_services[]="megashare.com_member";
$max_file_size["megashare.com_member"]= 1000;
$page_upload["megashare.com_member"] = "megashare.com_member.php";
?>
