<?php
$upload_services[]="filesavr.com_member";
$max_file_size["filesavr.com_member"]=10000;
$page_upload["filesavr.com_member"] = "filesavr.com_member.php";  
?>