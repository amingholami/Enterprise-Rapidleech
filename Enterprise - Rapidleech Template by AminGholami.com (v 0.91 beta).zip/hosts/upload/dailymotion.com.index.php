<?php 
$upload_services[]="dailymotion.com";
$max_file_size["dailymotion.com"]=2000;
$page_upload["dailymotion.com"] = "dailymotion.com.php";
?>