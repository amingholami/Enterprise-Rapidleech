<?php
$upload_services[] = "mega.1280.com_member";
$max_file_size["mega.1280.com_member"] = 500;
$page_upload["mega.1280.com_member"] = "mega.1280.com_member.php";  
?>