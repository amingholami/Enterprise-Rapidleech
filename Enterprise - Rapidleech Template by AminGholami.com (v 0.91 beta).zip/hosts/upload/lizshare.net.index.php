<?php
$upload_services[]="lizshare.net";
$max_file_size["lizshare.net"]=1000;
$page_upload["lizshare.net"] = "lizshare.net.php";  
?>