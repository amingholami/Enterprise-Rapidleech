<?php 
$upload_services[]="filefront.com";
$max_file_size["filefront.com"]=1000;
$page_upload["filefront.com"] = "filefront.com.php";  
?>