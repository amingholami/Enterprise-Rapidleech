<?php 
$upload_services[]="hotfile.com";
$max_file_size["hotfile.com"]=400;
$page_upload["hotfile.com"] = "hotfile.com.php";  
?>