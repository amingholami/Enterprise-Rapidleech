<?php
$upload_services[]="quickupload.net_member";
$max_file_size["quickupload.net_member"]=1000;
$page_upload["quickupload.net_member"] = "quickupload.net_member.php";  
?>