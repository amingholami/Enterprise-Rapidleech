<?php 
$upload_services[] = "4fastfile.com";
$max_file_size["4fastfile.com"] = 1024;
$page_upload["4fastfile.com"]  = "4fastfile.com.php";  
?>