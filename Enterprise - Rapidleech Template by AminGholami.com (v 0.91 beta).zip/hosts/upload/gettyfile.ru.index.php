<?php
$upload_services[]="gettyfile.ru";
$max_file_size["gettyfile.ru"]=4812;
$page_upload["gettyfile.ru"] = "gettyfile.ru.php";  
?>