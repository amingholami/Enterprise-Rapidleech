<?php
$upload_services[]="dl4.ru";
$max_file_size["dl4.ru"]=100;
$page_upload["dl4.ru"] = "dl4.ru.php";
?>