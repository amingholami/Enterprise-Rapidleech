<?php
$upload_services[]="filebeam.com";
$max_file_size["filebeam.com"]=100;
$page_upload["filebeam.com"] = "filebeam.com.php";  
?>