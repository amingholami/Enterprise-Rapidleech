<?php 
$upload_services[]="fileserve.com_premium";
$max_file_size["fileserve.com_premium"]=2048;
$page_upload["fileserve.com_premium"] = "fileserve.com_premium.php";  
?>
