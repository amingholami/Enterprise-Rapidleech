<?php
$upload_services[]="enterupload.com_member";
$max_file_size["enterupload.com_member"]=500;
$page_upload["enterupload.com_member"] = "enterupload.com_member.php";  
?>