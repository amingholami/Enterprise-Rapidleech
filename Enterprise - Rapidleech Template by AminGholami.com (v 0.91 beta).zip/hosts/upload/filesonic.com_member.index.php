<?php
$upload_services[]="filesonic.com_member";
$max_file_size["filesonic.com_member"]= 1024;
$page_upload["filesonic.com_member"] = "filesonic.com_member.php";
?>