<?php
if (!defined('RAPIDLEECH')) {
	require('../deny.php');
	exit;
}

include(TEMPLATE_DIR.'header.php');
include(TEMPLATE_DIR.'main.php');
include(TEMPLATE_DIR.'footer.php');
?>